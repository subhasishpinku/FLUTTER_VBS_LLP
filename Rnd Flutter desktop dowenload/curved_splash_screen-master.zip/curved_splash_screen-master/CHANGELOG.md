## [1.0.0+1] - 17/3/2021.

Update Readme.

## [1.0.0] - 17/3/2021.

initial release.
