import 'package:flutter_test/flutter_test.dart';

import 'package:curved_splash_screen/curved_splash_screen.dart';

void main() {
  test('adds one to input values', () {});
}
