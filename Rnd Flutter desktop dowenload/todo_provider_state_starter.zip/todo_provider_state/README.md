# todo_provider_state

1. ChangeNotifierProvider + ChangeNotifierProxyProvider
2. ChangeNotifierProvider + ProxyProvider
3. **StateNotifierProvider**
