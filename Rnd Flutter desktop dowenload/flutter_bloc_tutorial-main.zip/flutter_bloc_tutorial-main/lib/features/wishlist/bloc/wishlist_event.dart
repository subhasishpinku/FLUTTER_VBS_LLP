part of 'wishlist_bloc.dart';

@immutable
abstract class WishlistEvent {}
