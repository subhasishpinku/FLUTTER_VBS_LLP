


import 'package:flutter_bloc_tutorial/features/home/models/home_product_data_model.dart';

List<ProductDataModel> cartItems = [];