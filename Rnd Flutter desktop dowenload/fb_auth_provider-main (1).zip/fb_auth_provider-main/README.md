## fb_auth_provider

### Firebase Authentication App
- Email / Password
- ***Provider + StreamProvider + ChangeNotifierProvider + ChangeNotifierProxyProvider***
- Provider + StreamProvider + StateNotifierProvider
