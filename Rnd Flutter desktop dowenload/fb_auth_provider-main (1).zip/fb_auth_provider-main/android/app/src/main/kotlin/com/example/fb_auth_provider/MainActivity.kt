package com.example.fb_auth_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
