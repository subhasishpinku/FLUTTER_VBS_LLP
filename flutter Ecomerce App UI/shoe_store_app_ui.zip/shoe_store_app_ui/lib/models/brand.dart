class Brand {
  String name;
  String iconURL;

  Brand({
    required this.name,
    required this.iconURL,
  });
}
