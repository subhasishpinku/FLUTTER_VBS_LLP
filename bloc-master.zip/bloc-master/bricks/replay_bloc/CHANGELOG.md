# 0.2.1

- chore: update copyright year
- chore: update logo image refs

# 0.2.0

- feat: add support for `equatable`
- feat: add support for `freezed`

# 0.1.3

- fix: add missing `extends ReplayEvent`

# 0.1.2

- docs: add badges to README
- docs: use dark logo variant

# 0.1.1

- docs: minor README update

# 0.1.0

- feat: initial release with support for basic replay bloc generation
