export './{{name.snakeCase()}}_page.dart';
