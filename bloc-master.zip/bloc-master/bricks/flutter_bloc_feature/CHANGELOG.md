# 0.3.1

- chore: update copyright year
- chore: update logo image refs

# 0.3.0

- feat: upgrade to Dart 3.0
  - use `sealed` classes for bloc events

# 0.2.1

- fix: upgrade to mason v0.1.0-dev.40
  - deps: remove dependency on `package:recase`

# 0.2.0

- feat: add support for `equatable`
- feat: add support for `freezed`

# 0.1.0+1

- feat: initial release 🎉
