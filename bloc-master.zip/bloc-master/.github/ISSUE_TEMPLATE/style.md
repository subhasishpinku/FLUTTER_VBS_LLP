---
name: Style Changes
about: Changes that do not affect the meaning of the code (white-space, formatting, missing semi-colons, etc)
title: "style: "
labels: style
---

**Description**

Clearly describe what you are looking to change and why.
