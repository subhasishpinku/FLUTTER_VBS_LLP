package com.example.flutter_complex_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
