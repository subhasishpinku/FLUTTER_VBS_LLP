package com.example.flutter_dynamic_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
