import 'package:flutter/material.dart';
import 'package:flutter_dynamic_form/app.dart';
import 'package:flutter_dynamic_form/new_car_repository.dart';

void main() => runApp(MyApp(newCarRepository: NewCarRepository()));
