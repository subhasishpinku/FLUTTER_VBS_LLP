export 'bloc/new_car_bloc.dart';
export 'view/new_car_page.dart';
