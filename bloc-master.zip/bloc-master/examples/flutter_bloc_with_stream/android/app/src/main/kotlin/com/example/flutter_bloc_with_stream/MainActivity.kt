package com.example.flutter_bloc_with_stream

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
