package com.example.flutter_firebase_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
