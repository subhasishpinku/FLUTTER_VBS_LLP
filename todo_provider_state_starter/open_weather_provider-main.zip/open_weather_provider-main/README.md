# open_weather_provider

- ChangeNotifierProvider + ChangeNotifierProxyProvider
