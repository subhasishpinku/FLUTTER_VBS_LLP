package com.example.open_weather_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
