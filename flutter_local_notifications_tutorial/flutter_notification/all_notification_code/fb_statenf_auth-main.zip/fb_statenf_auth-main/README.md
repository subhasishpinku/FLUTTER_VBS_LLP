## fb_statenf_auth

### Firebase Authentication App
- Email / Password
- Provider + StreamProvider + ChangeNotifierProvider + ChangeNotifierProxyProvider
- ***Provider + StreamProvider + StateNotifierProvider***