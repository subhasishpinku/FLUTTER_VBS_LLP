package com.example.google_maps_yt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
